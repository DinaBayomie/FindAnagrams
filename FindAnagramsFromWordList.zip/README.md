# FindAnagrams
This CLI program reads a dictionary file and search for the anagrams of the user input test. 


